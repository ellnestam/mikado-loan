package com.ssem.loan;

import org.eclipse.jetty.server.Request;

public class StubbedRequest extends Request {

    public StubbedRequest() {
    }

}
