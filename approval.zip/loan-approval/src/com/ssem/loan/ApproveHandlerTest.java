package com.ssem.loan;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

public class ApproveHandlerTest {

    ApproveHandler loanHandler;
    StubbedRequest baseRequest;
    StubbedResponse response;
    MemoryLoanRepository repository;

    @Before
    public void setUp() {
        repository = new MemoryLoanRepository();
        loanHandler = new ApproveHandler(repository);
        baseRequest = new StubbedRequest();
        response = new StubbedResponse();
    }

    @Test
    public void loanApplicationsCanBeApproved() throws Exception {
        long id = repository.apply(100, "a@a.com");
        StubbedServletRequest request = new StubbedServletRequest(
                approveParams(id + ""));
        loanHandler.handle(null, baseRequest, request, response);
        response.getWriter().flush();
        assertEquals("{\"id\":" + id + "}\n", response.responseAsText());
    }

    private HashMap<String, String> approveParams(String ticketId) {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("action", ApproveHandler.APPROVE);
        params.put("ticketId", ticketId);
        return params;
    }
}
